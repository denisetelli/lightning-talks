import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.FindOneAndUpdateOptions;
import com.mongodb.client.model.ReturnDocument;
import com.mongodb.client.model.Updates;
import javafx.beans.binding.When;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static com.mongodb.client.model.Sorts.ascending;

public class MongoDbApp {

    public static void main(String[] args) {
        //CONNECTION
        System.out.println("Connecting to MongoClient server!");
        MongoClient client = new MongoClient();
        MongoDatabase database = client.getDatabase("test");

        //GET COLLECTION
        MongoCollection<Document> students = database.getCollection("students");

        //INSERT OPERATIONS
//        Document joao = new Document("nome", "Joao")
//                .append("data_nascimento", new Date(1995, 04, 10))
//                .append("curso", new Document("nome", "Historia"))
//                .append("notas", Arrays.asList(10, 9, 8))
//                .append("habilidades", Arrays.asList(new Document()
//                                .append("nome", "Ingles ")
//                                .append("nível", "Básico"),
//                        new Document()
//                                .append("nome", "Taekwondo")
//                                .append("nível", "Medio")));
//        students.insertOne(joao);
//
//        students.insertMany(Arrays.asList(new Document("nome", "Felipe")
//                        .append("data_nascimento", new Date(1994, 04, 26))
//                        .append("curso", new Document("nome", "Medicina"))
//                        .append("notas", Arrays.asList(9, 7, 8))
//                        .append("habilidades", Arrays.asList(new Document()
//                                        .append("nome", "Ingles ")
//                                        .append("nível", "Avançado"),
//                                new Document()
//                                        .append("nome", "Espanhol")
//                                        .append("nível", "Basico"))),
//                new Document("nome", "Ana")
//                        .append("data_nascimento", new Date(1993, 06, 15))
//                        .append("curso", new Document("nome", "Artes"))
//                        .append("notas", Arrays.asList(9, 7, 8))
//                        .append("habilidades", Arrays.asList(new Document()
//                                .append("nome", "Canto")
//                                .append("nível", "Avançado")))
//        ));

        //READ OPERATIONS
        List<Document> results = new ArrayList<>();
        students.find().sort(ascending("nome")).into(results);
        for (Document result : results) {
            System.out.println(result.toJson());
        }

        Document fisrtStudent = students.find().first();
        System.out.println(fisrtStudent);

        Document luana = students.find(Filters.eq("nome", "Luana")).first();
        System.out.println(luana);

        //UPDATE OPERATIONS
//        students.updateOne(Filters.eq("nome", "Julia"),
//                new Document("$set", new Document("data_nascimento", new Date(2000, Calendar.MAY, 13))));
//        System.out.println(students.find(Filters.eq("nome", "Julia")).first());
//
//            students.replaceOne(Filters.eq("nome", "Joao"),
//                    new Document("nome", "Joao Silva")
//                .append("data_nascimento", new Date(1995, 04, 15))
//                .append("curso", new Document("nome", "Historia"))
//                .append("notas", Arrays.asList(10, 9, 8))
//                .append("habilidades", Arrays.asList(new Document()
//                                .append("nome", "Ingles ")
//                                       .append("nível", "Médio"))));

        Bson luisFilter = Filters.eq("nome", "Luis");
        Bson update = Updates.push("notas", 3);
        FindOneAndUpdateOptions options = new FindOneAndUpdateOptions()
                .returnDocument(ReturnDocument.AFTER);
        Document result = students.findOneAndUpdate(luisFilter, update, options);
        System.out.println(result.toJson());

        //DELETE OPERATIONS
        students.deleteOne(Filters.eq("nome", "Julia"));
        students.findOneAndDelete(Filters.eq("nome", "Luana"));

        client.close();
    }

}